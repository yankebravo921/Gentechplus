import { useEffect } from 'react';
import Navbar from './components/Navbar';
import Hero from './sections/Hero';
import Services from './sections/Services';
import Process from './sections/Process';
import FeaturedWork from './sections/FeaturedWork';
import CTA from './sections/CTA';
import TextAnimation from './sections/TextAnimation';

function App() {
  useEffect(() => {
    // Smooth scroll polyfill for older browsers
    document.documentElement.style.scrollBehavior = 'smooth';
    
    return () => {
      document.documentElement.style.scrollBehavior = 'auto';
    };
  }, []);

  return (
    <div className="relative">
      {/* Main content sections */}
      <main className="relative">
        <section id="home">
          <Hero />
        </section>
        
        <section id="services">
          <Services />
        </section>
        
        <section id="process">
          <Process />
        </section>
        
        <section id="work">
          <FeaturedWork />
        </section>
        
        <section id="contact">
          <CTA />
        </section>
        
        <TextAnimation />
      </main>

      {/* Fixed bottom navbar */}
      <Navbar />
    </div>
  );
}

export default App;
