import { motion, useInView } from 'framer-motion';
import { useRef } from 'react';

const services = [
  { name: 'DESIGN', angle: 180 },
  { name: 'DEVELOPMENT', angle: 270 },
  { name: 'SEO', angle: 0 },
  { name: 'E-COMMERCE', angle: 90 },
];

const RotatingCenterLogo = () => {
  return (
    <div className="relative w-24 h-32 sm:w-32 sm:h-40 md:w-40 md:h-52 lg:w-48 lg:h-60 perspective-1000">
      <motion.div
        className="w-full h-full preserve-3d"
        animate={{ rotateY: 360 }}
        transition={{
          duration: 10,
          repeat: Infinity,
          ease: "linear"
        }}
      >
        <svg
          viewBox="0 0 150 180"
          className="w-full h-full"
          style={{ filter: 'drop-shadow(0 15px 30px rgba(163, 230, 53, 0.4))' }}
        >
          <defs>
            <linearGradient id="limeGradient2" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#bef264" />
              <stop offset="50%" stopColor="#a3e635" />
              <stop offset="100%" stopColor="#65a30d" />
            </linearGradient>
            <pattern id="grid" width="10" height="10" patternUnits="userSpaceOnUse">
              <path d="M 10 0 L 0 0 0 10" fill="none" stroke="#65a30d" strokeWidth="0.5" opacity="0.3"/>
            </pattern>
          </defs>
          {/* Main A shape */}
          <path
            d="M75 15 L135 165 L105 165 L90 120 L60 120 L45 165 L15 165 Z"
            fill="url(#limeGradient2)"
            stroke="#65a30d"
            strokeWidth="1.5"
          />
          <path
            d="M75 15 L135 165 L105 165 L90 120 L60 120 L45 165 L15 165 Z"
            fill="url(#grid)"
          />
          {/* Inner cutout */}
          <path
            d="M75 60 L85 90 L65 90 Z"
            fill="#f5f5f5"
          />
          {/* Side depth */}
          <path
            d="M135 165 L142 172 L112 172 L105 165 Z"
            fill="#65a30d"
          />
          <path
            d="M45 165 L52 172 L22 172 L15 165 Z"
            fill="#65a30d"
          />
        </svg>
      </motion.div>
    </div>
  );
};

const CircularDashedLine = () => {
  return (
    <svg
      className="absolute w-[280px] h-[280px] sm:w-[400px] sm:h-[400px] md:w-[500px] md:h-[500px] lg:w-[600px] lg:h-[600px]"
      viewBox="0 0 600 600"
      fill="none"
    >
      <motion.circle
        cx="300"
        cy="300"
        r="280"
        stroke="#a3e635"
        strokeWidth="2"
        strokeDasharray="20 15"
        fill="none"
        initial={{ pathLength: 0, rotate: -90 }}
        whileInView={{ pathLength: 1, rotate: -90 }}
        viewport={{ once: true }}
        transition={{ duration: 2, ease: "easeInOut" }}
      />
      {/* Tick marks */}
      {[...Array(24)].map((_, i) => {
        const angle = (i * 15 * Math.PI) / 180;
        const x1 = 300 + 265 * Math.cos(angle);
        const y1 = 300 + 265 * Math.sin(angle);
        const x2 = 300 + 280 * Math.cos(angle);
        const y2 = 300 + 280 * Math.sin(angle);
        return (
          <motion.line
            key={i}
            x1={x1}
            y1={y1}
            x2={x2}
            y2={y2}
            stroke="#a3e635"
            strokeWidth="2"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.5 + i * 0.02 }}
          />
        );
      })}
    </svg>
  );
};

const ServiceLabel = ({ name, angle, index }: { name: string; angle: number; index: number }) => {
  // Responsive radius based on screen size
  const radius = typeof window !== 'undefined' && window.innerWidth < 768 ? 160 : typeof window !== 'undefined' && window.innerWidth < 1024 ? 220 : 320;
  const radian = (angle * Math.PI) / 180;
  const x = Math.cos(radian) * radius;
  const y = Math.sin(radian) * radius;

  return (
    <motion.div
      className="absolute flex items-center gap-1.5 md:gap-2"
      style={{
        left: `calc(50% + ${x}px)`,
        top: `calc(50% + ${y}px)`,
        transform: 'translate(-50%, -50%)',
      }}
      initial={{ opacity: 0, scale: 0 }}
      whileInView={{ opacity: 1, scale: 1 }}
      viewport={{ once: true }}
      transition={{ delay: 0.8 + index * 0.15, duration: 0.4 }}
    >
      <span className="w-1.5 h-1.5 md:w-2 md:h-2 bg-lime rounded-full flex-shrink-0" />
      <span className="font-display text-sm sm:text-base md:text-lg lg:text-xl text-black tracking-wide whitespace-nowrap">{name}</span>
    </motion.div>
  );
};

const HoneycombDecoration = ({ className = "" }: { className?: string }) => (
  <svg
    className={`absolute ${className} w-20 h-24 md:w-32 md:h-36`}
    viewBox="0 0 150 170"
    fill="none"
  >
    {[...Array(9)].map((_, i) => {
      const row = Math.floor(i / 3);
      const col = i % 3;
      const x = col * 50 + (row % 2) * 25;
      const y = row * 45;
      const isFilled = [1, 3, 5, 7].includes(i);
      return (
        <path
          key={i}
          d={`M${x + 25} ${y} L${x + 50} ${y + 15} L${x + 50} ${y + 40} L${x + 25} ${y + 55} L${x} ${y + 40} L${x} ${y + 15} Z`}
          fill={isFilled ? "#a3e635" : "none"}
          stroke="#a3e635"
          strokeWidth="1"
          fillOpacity={isFilled ? 0.25 : 0}
        />
      );
    })}
  </svg>
);

export default function Services() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className="relative min-h-screen bg-[#f5f5f5] overflow-hidden flex items-center py-16 md:py-20">
      {/* Honeycomb decorations */}
      <HoneycombDecoration className="left-2 md:left-4 top-10 md:top-20 opacity-50 hidden sm:block" />
      <HoneycombDecoration className="right-4 md:right-8 bottom-10 md:bottom-20 opacity-40 scale-75 hidden md:block" />
      <HoneycombDecoration className="left-8 md:left-16 bottom-20 md:bottom-32 opacity-30 scale-50 hidden lg:block" />

      <div className="container mx-auto px-4 sm:px-6 lg:px-12">
        {/* Section Title */}
        <motion.div
          className="text-center mb-12 md:mb-20"
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
        >
          <h2 className="font-display text-3xl sm:text-4xl md:text-5xl lg:text-6xl xl:text-7xl">
            <span className="text-black">WE ARE </span>
            <span className="text-lime">GOOD</span>
            <span className="text-black"> AT</span>
          </h2>
        </motion.div>

        {/* Circular services layout */}
        <div className="relative flex items-center justify-center h-[350px] sm:h-[450px] md:h-[550px] lg:h-[700px]">
          {/* Dashed circle */}
          <CircularDashedLine />

          {/* Center rotating logo */}
          <motion.div
            className="relative z-10"
            initial={{ opacity: 0, scale: 0.5 }}
            animate={isInView ? { opacity: 1, scale: 1 } : {}}
            transition={{ delay: 0.3, duration: 0.6 }}
          >
            <RotatingCenterLogo />
          </motion.div>

          {/* Service labels positioned around the circle */}
          <div className="absolute inset-0 flex items-center justify-center">
            {services.map((service, index) => (
              <ServiceLabel
                key={service.name}
                name={service.name}
                angle={service.angle}
                index={index}
              />
            ))}
          </div>

          {/* Horizontal guide lines - hidden on mobile */}
          <motion.div
            className="absolute w-full h-px bg-gray-300 hidden md:block"
            initial={{ scaleX: 0 }}
            animate={isInView ? { scaleX: 1 } : {}}
            transition={{ delay: 1, duration: 0.8 }}
          />
          <motion.div
            className="absolute h-full w-px bg-gray-300 hidden md:block"
            initial={{ scaleY: 0 }}
            animate={isInView ? { scaleY: 1 } : {}}
            transition={{ delay: 1.2, duration: 0.8 }}
          />
        </div>
      </div>
    </section>
  );
}
