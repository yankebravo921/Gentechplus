import { motion } from 'framer-motion';
import { useEffect, useState } from 'react';

const RotatingLogo = () => {
  return (
    <div className="relative w-32 h-40 sm:w-40 sm:h-48 md:w-64 md:h-64 lg:w-80 lg:h-80 perspective-1000">
      <motion.div
        className="w-full h-full preserve-3d"
        animate={{ rotateY: 360 }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: "linear"
        }}
      >
        {/* 3D Logo - Stylized A */}
        <svg
          viewBox="0 0 200 240"
          className="w-full h-full drop-shadow-2xl"
          style={{ filter: 'drop-shadow(0 20px 40px rgba(163, 230, 53, 0.4))' }}
        >
          <defs>
            <linearGradient id="limeGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#bef264" />
              <stop offset="50%" stopColor="#a3e635" />
              <stop offset="100%" stopColor="#65a30d" />
            </linearGradient>
            <filter id="glow">
              <feGaussianBlur stdDeviation="4" result="coloredBlur"/>
              <feMerge>
                <feMergeNode in="coloredBlur"/>
                <feMergeNode in="SourceGraphic"/>
              </feMerge>
            </filter>
          </defs>
          {/* Main A shape with 3D effect */}
          <path
            d="M100 20 L180 200 L140 200 L120 150 L80 150 L60 200 L20 200 Z"
            fill="url(#limeGradient)"
            stroke="#65a30d"
            strokeWidth="2"
            filter="url(#glow)"
          />
          {/* Inner cutout for 3D effect */}
          <path
            d="M100 80 L115 120 L85 120 Z"
            fill="#f5f5f5"
          />
          {/* Side depth */}
          <path
            d="M180 200 L190 210 L150 210 L140 200 Z"
            fill="#65a30d"
          />
          <path
            d="M60 200 L70 210 L30 210 L20 200 Z"
            fill="#65a30d"
          />
        </svg>
      </motion.div>
    </div>
  );
};

const HoneycombDecoration = ({ className = "" }: { className?: string }) => (
  <svg
    className={`absolute ${className} w-24 h-28 md:w-40 md:h-44`}
    viewBox="0 0 200 230"
    fill="none"
  >
    {[...Array(12)].map((_, i) => {
      const row = Math.floor(i / 4);
      const col = i % 4;
      const x = col * 50 + (row % 2) * 25;
      const y = row * 45;
      const isFilled = [0, 2, 5, 7, 9, 10].includes(i);
      return (
        <motion.path
          key={i}
          d={`M${x + 25} ${y} L${x + 50} ${y + 15} L${x + 50} ${y + 40} L${x + 25} ${y + 55} L${x} ${y + 40} L${x} ${y + 15} Z`}
          fill={isFilled ? "#a3e635" : "none"}
          stroke="#a3e635"
          strokeWidth="1"
          fillOpacity={isFilled ? 0.3 : 0}
          initial={{ opacity: 0, scale: 0 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: i * 0.05, duration: 0.3 }}
        />
      );
    })}
  </svg>
);

export default function Hero() {
  const [scrollY, setScrollY] = useState(0);

  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY);
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <section className="relative min-h-screen bg-[#f5f5f5] overflow-hidden flex items-center">
      {/* Honeycomb decorations - hidden on small mobile */}
      <HoneycombDecoration className="left-2 md:left-8 bottom-20 md:bottom-32 opacity-60 hidden sm:block" />
      <HoneycombDecoration className="right-4 md:right-16 top-16 md:top-24 opacity-40 scale-75 hidden md:block" />

      {/* Vertical scroll indicator line - hidden on mobile */}
      <motion.div
        className="absolute right-4 md:right-8 top-1/2 -translate-y-1/2 w-1 h-24 md:h-32 bg-gray-300 rounded-full overflow-hidden hidden sm:block"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1 }}
      >
        <motion.div
          className="w-full bg-lime"
          style={{ height: `${Math.min((scrollY / 500) * 100, 100)}%` }}
        />
      </motion.div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-12 py-16 md:py-20">
        <div className="grid lg:grid-cols-2 gap-8 md:gap-12 items-center">
          {/* Left content */}
          <motion.div
            className="space-y-6 md:space-y-8 order-2 lg:order-1"
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          >
            <p className="text-base md:text-lg lg:text-xl text-gray-800 max-w-md leading-relaxed">
              We design immersive, motion-driven websites that command attention and guide users to act. Clean builds. Sharp strategy. Zero fluff.
            </p>
            
            <motion.button
              className="bg-lime text-black font-semibold px-6 md:px-8 py-3 md:py-4 rounded-lg hover:bg-lime-dark transition-colors duration-300 shadow-lg hover:shadow-xl text-sm md:text-base"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              LET'S TALK
            </motion.button>
          </motion.div>

          {/* Right content - Large typography */}
          <motion.div
            className="relative order-1 lg:order-2"
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2, ease: "easeOut" }}
          >
            <div className="relative z-10">
              <h1 className="font-display text-3xl sm:text-4xl md:text-5xl lg:text-6xl xl:text-7xl leading-none tracking-tight">
                <motion.span
                  className="block text-black"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 }}
                >
                  YOUR BRAND
                </motion.span>
                <motion.span
                  className="block text-lime"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 }}
                >
                  DESERVES MORE
                </motion.span>
                <motion.span
                  className="block text-black"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.5 }}
                >
                  THAN A PRETTY
                </motion.span>
                <motion.span
                  className="block text-black"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.6 }}
                >
                  WEBSITE.
                </motion.span>
              </h1>
            </div>

            {/* 3D Logo overlay */}
            <motion.div
              className="absolute -left-4 sm:-left-8 md:-left-16 top-1/2 -translate-y-1/2 z-20"
              initial={{ opacity: 0, scale: 0.5 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.7, duration: 0.5 }}
            >
              <RotatingLogo />
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
