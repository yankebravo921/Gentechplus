import { motion, useScroll, useTransform } from 'framer-motion';
import { useRef } from 'react';

const phrases = [
  'DESIGN WITH PURPOSE',
  'BUILT TO CONVERT',
  'BUILT DIFFERENT FOR YOU',
];

const CornerCross = ({ position }: { position: 'tl' | 'tr' | 'bl' | 'br' }) => {
  const positionClasses = {
    tl: 'top-4 left-4 md:top-8 md:left-8',
    tr: 'top-4 right-4 md:top-8 md:right-8',
    bl: 'bottom-4 left-4 md:bottom-8 md:left-8',
    br: 'bottom-4 right-4 md:bottom-8 md:right-8',
  };

  return (
    <motion.div
      className={`absolute ${positionClasses[position]} w-4 h-4 md:w-6 md:h-6`}
      initial={{ opacity: 0, scale: 0 }}
      whileInView={{ opacity: 1, scale: 1 }}
      viewport={{ once: true }}
      transition={{ delay: 0.5, duration: 0.3 }}
    >
      <svg viewBox="0 0 24 24" fill="none" className="w-full h-full">
        <path d="M12 0 V24 M0 12 H24" stroke="white" strokeWidth="2" />
      </svg>
    </motion.div>
  );
};

// Scroll-triggered text section with crossfade
const ScrollTextSection = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end end"]
  });

  // Create opacity transforms for each phrase
  // Phrase 1: visible from 0% to 25%, fades out 25% to 35%
  const opacity1 = useTransform(scrollYProgress, [0, 0.2, 0.3, 0.35], [1, 1, 0.5, 0]);
  const y1 = useTransform(scrollYProgress, [0, 0.3, 0.35], [0, 0, -50]);
  
  // Phrase 2: fades in 25% to 35%, visible 35% to 55%, fades out 55% to 65%
  const opacity2 = useTransform(scrollYProgress, [0.25, 0.35, 0.55, 0.65], [0, 1, 1, 0]);
  const y2 = useTransform(scrollYProgress, [0.25, 0.35, 0.55, 0.65], [50, 0, 0, -50]);
  
  // Phrase 3: fades in 55% to 65%, visible 65% to 100%
  const opacity3 = useTransform(scrollYProgress, [0.55, 0.65, 1], [0, 1, 1]);
  const y3 = useTransform(scrollYProgress, [0.55, 0.65, 1], [50, 0, 0]);

  return (
    <div ref={containerRef} className="h-[300vh] relative">
      <div className="sticky top-0 h-screen flex items-center justify-center overflow-hidden bg-black">
        {/* All phrases positioned absolutely in the same spot */}
        <div className="relative w-full h-24 md:h-32 lg:h-48">
          {/* Phrase 1: DESIGN WITH PURPOSE */}
          <motion.div
            className="absolute inset-0 flex items-center justify-center"
            style={{ opacity: opacity1, y: y1 }}
          >
            <h2 className="font-display text-4xl sm:text-5xl md:text-7xl lg:text-8xl xl:text-9xl text-white text-center whitespace-nowrap">
              {phrases[0]}
            </h2>
          </motion.div>
          
          {/* Phrase 2: BUILT TO CONVERT */}
          <motion.div
            className="absolute inset-0 flex items-center justify-center"
            style={{ opacity: opacity2, y: y2 }}
          >
            <h2 className="font-display text-4xl sm:text-5xl md:text-7xl lg:text-8xl xl:text-9xl text-white text-center whitespace-nowrap">
              {phrases[1]}
            </h2>
          </motion.div>
          
          {/* Phrase 3: BUILT DIFFERENT FOR YOU */}
          <motion.div
            className="absolute inset-0 flex items-center justify-center"
            style={{ opacity: opacity3, y: y3 }}
          >
            <h2 className="font-display text-4xl sm:text-5xl md:text-7xl lg:text-8xl xl:text-9xl text-white text-center whitespace-nowrap">
              {phrases[2]}
            </h2>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

// Vortex tunnel effect at the end
const VortexSection = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start end", "end start"]
  });

  const scale = useTransform(scrollYProgress, [0, 0.5], [0, 3]);
  const opacity = useTransform(scrollYProgress, [0, 0.3, 0.7, 1], [0, 1, 1, 0]);

  return (
    <div ref={containerRef} className="h-[150vh] relative">
      <div className="sticky top-0 h-screen flex items-center justify-center overflow-hidden bg-black">
        {/* Vortex tunnel effect */}
        <motion.div
          className="absolute inset-0 flex items-center justify-center"
          style={{ scale, opacity }}
        >
          {/* Swirling spiral */}
          <svg 
            className="absolute w-[300px] h-[300px] md:w-[500px] md:h-[500px] lg:w-[700px] lg:h-[700px]" 
            viewBox="0 0 700 700"
          >
            <defs>
              <radialGradient id="vortexGrad1" cx="50%" cy="50%" r="50%">
                <stop offset="0%" stopColor="#bef264" />
                <stop offset="30%" stopColor="#a3e635" />
                <stop offset="60%" stopColor="#65a30d" />
                <stop offset="100%" stopColor="#1a1a1a" />
              </radialGradient>
              <filter id="glow1">
                <feGaussianBlur stdDeviation="10" result="coloredBlur"/>
                <feMerge>
                  <feMergeNode in="coloredBlur"/>
                  <feMergeNode in="SourceGraphic"/>
                </feMerge>
              </filter>
            </defs>
            
            {/* Spiral arms */}
            {[...Array(12)].map((_, i) => {
              const rotation = i * 30;
              return (
                <motion.g key={i} transform={`rotate(${rotation} 350 350)`}>
                  <motion.path
                    d="M350 350 Q400 300 450 350 Q500 400 450 450 Q400 500 350 450 Q300 400 350 350"
                    fill="none"
                    stroke="url(#vortexGrad1)"
                    strokeWidth="8"
                    strokeLinecap="round"
                    initial={{ pathLength: 0, opacity: 0 }}
                    whileInView={{ pathLength: 1, opacity: 0.8 }}
                    viewport={{ once: true }}
                    transition={{ duration: 2, delay: i * 0.1 }}
                  />
                </motion.g>
              );
            })}
            
            {/* Center glow */}
            <circle cx="350" cy="350" r="100" fill="url(#vortexGrad1)" filter="url(#glow1)" opacity="0.8" />
          </svg>

          {/* Rotating rings */}
          {[...Array(8)].map((_, i) => (
            <motion.div
              key={`ring-${i}`}
              className="absolute rounded-full border-2 border-lime/40"
              style={{
                width: `${(i + 1) * 80}px`,
                height: `${(i + 1) * 80}px`,
              }}
              animate={{ rotate: [0, 360 * (i % 2 === 0 ? 1 : -1)] }}
              transition={{
                duration: 4 + i,
                repeat: Infinity,
                ease: "linear",
              }}
            />
          ))}

          {/* Central bright glow */}
          <motion.div
            className="absolute w-32 h-32 md:w-48 md:h-48 bg-lime rounded-full"
            style={{
              filter: 'blur(40px)',
              boxShadow: '0 0 100px 50px rgba(163, 230, 53, 0.8)'
            }}
            animate={{ 
              scale: [1, 1.3, 1],
              opacity: [0.6, 1, 0.6]
            }}
            transition={{ duration: 2, repeat: Infinity }}
          />
        </motion.div>
      </div>
    </div>
  );
};

export default function TextAnimation() {
  return (
    <section className="relative bg-black overflow-hidden">
      {/* Corner decorations */}
      <CornerCross position="tl" />
      <CornerCross position="tr" />
      <CornerCross position="bl" />
      <CornerCross position="br" />

      {/* Scroll-triggered text section with crossfade */}
      <ScrollTextSection />

      {/* Vortex tunnel animation */}
      <VortexSection />
    </section>
  );
}
